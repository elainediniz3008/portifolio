<?php
require 'db_config.php';

if (!isset($_GET['id'])) {
    header("Location: admin.php");
    exit;
}

$id = $_GET['id'];

// Buscar projeto
$stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->execute([$id]);
$project = $stmt->fetch();

if (!$project) {
    header("Location: admin.php");
    exit;
}

// Processar atualização
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $currentImage = $project['image'];
    $newImage = $currentImage;

    // Processar remoção de imagem
    if (isset($_POST['remove_image']) && $_POST['remove_image'] === '1') {
        if ($currentImage && file_exists("uploads/" . $currentImage)) {
            unlink("uploads/" . $currentImage);
        }
        $newImage = null;
    }
    
    // Processar upload de nova imagem
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        // Remove imagem antiga se existir
        if ($currentImage && file_exists("uploads/" . $currentImage)) {
            unlink("uploads/" . $currentImage);
        }
        
        $uploadDir = 'uploads/';
        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $uploadPath = $uploadDir . $filename;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
            $newImage = $filename;
        }
    }

    // Atualizar no banco
    try {
        $stmt = $pdo->prepare("UPDATE projects SET name = ?, description = ?, image = ? WHERE id = ?");
        $stmt->execute([$name, $description, $newImage, $id]);
        
        header("Location: admin.php");
        exit;
    } catch (PDOException $e) {
        die("Erro ao atualizar projeto: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Projeto</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Editar Projeto</h1>
        <nav>
            <a href="index.html">Página Inicial</a>
            <a href="admin.php">Voltar</a>
        </nav>
    </header>

    <div class="container">
        <section class="form-section">
            <h2>Editar Projeto: <?= htmlspecialchars($project['name']) ?></h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Nome do Projeto:</label>
                    <input type="text" id="name" name="name" 
                           value="<?= htmlspecialchars($project['name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Descrição do Projeto:</label>
                    <textarea id="description" name="description" required><?= 
                        htmlspecialchars($project['description']) 
                    ?></textarea>
                </div>
                
                <div class="form-group">
                    <label>Imagem Atual:</label>
                    <?php if ($project['image']): ?>
                        <div>
                            <img src="uploads/<?= htmlspecialchars($project['image']) ?>" 
                                 style="max-width: 200px; display: block; margin-bottom: 10px;">
                            <label>
                                <input type="checkbox" name="remove_image" value="1"> Remover imagem atual
                            </label>
                        </div>
                    <?php else: ?>
                        <p>Nenhuma imagem cadastrada</p>
                    <?php endif; ?>
                    
                    <label for="image">Nova Imagem (opcional):</label>
                    <input type="file" id="image" name="image" accept="image/*">
                </div>
                
                <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            </form>
        </section>
    </div>
</body>
</html>