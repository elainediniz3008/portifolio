<?php
require 'db_config.php';

// Processar busca
$search = $_GET['search'] ?? '';
$projects = [];

if (!empty($search)) {
    $stmt = $pdo->prepare("SELECT * FROM projects 
                          WHERE name LIKE :search OR description LIKE :search
                          ORDER BY created_at DESC");
    $searchTerm = "%$search%";
    $stmt->bindParam(':search', $searchTerm);
    $stmt->execute();
    $projects = $stmt->fetchAll();
} else {
    // Listar todos os projetos se não houver busca
    $stmt = $pdo->query("SELECT * FROM projects ORDER BY created_at DESC");
    $projects = $stmt->fetchAll();
}

// Processar exclusão
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // Primeiro obtém o nome da imagem para apagar o arquivo
    $stmt = $pdo->prepare("SELECT image FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $project = $stmt->fetch();
    
    if ($project && $project['image']) {
        $imagePath = "uploads/" . $project['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }
    
    // Depois deleta do banco
    $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    
    header("Location: admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Portfólio</title>
    <style>
        :root {
            --roxo-principal: #6a0dad;
            --roxo-claro: #9b59b6;
            --bege: #f5f5dc;
            --bege-escuro: #e6e6cc;
            --branco: #ffffff;
            --preto: #333333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background-color: var(--bege);
            color: var(--preto);
            line-height: 1.6;
        }

        header {
            background-color: var(--roxo-principal);
            color: var(--branco);
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        nav {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 1rem;
        }

        nav a {
            color: var(--branco);
            text-decoration: none;
            font-weight: bold;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: var(--roxo-claro);
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1.5rem;
        }

        .search-container {
            background-color: var(--branco);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .search-form {
            display: flex;
            gap: 0.5rem;
        }

        .search-form input {
            flex: 1;
            padding: 0.8rem;
            border: 1px solid var(--bege-escuro);
            border-radius: 4px;
            font-size: 1rem;
        }

        .search-form button {
            padding: 0 1.5rem;
        }

        .projects-table {
            width: 100%;
            border-collapse: collapse;
            background-color: var(--branco);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .projects-table th, .projects-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--bege-escuro);
        }

        .projects-table th {
            background-color: var(--roxo-principal);
            color: var(--branco);
        }

        .projects-table tr:nth-child(even) {
            background-color: var(--bege);
        }

        .projects-table tr:hover {
            background-color: var(--bege-escuro);
        }

        .project-image {
            max-width: 100px;
            max-height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }

        .actions {
            display: flex;
            gap: 0.5rem;
        }

        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .btn-primary {
            background-color: var(--roxo-principal);
            color: var(--branco);
        }

        .btn-primary:hover {
            background-color: var(--roxo-claro);
        }

        .btn-danger {
            background-color: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background-color: #c0392b;
        }

        .no-projects {
            text-align: center;
            padding: 2rem;
            background-color: var(--branco);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-section {
            background-color: var(--branco);
            border-radius: 8px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: var(--roxo-principal);
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid var(--bege-escuro);
            border-radius: 4px;
            font-size: 1rem;
        }

        .form-group textarea {
            min-height: 120px;
        }

        @media (max-width: 768px) {
            nav {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .search-form {
                flex-direction: column;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .projects-table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Painel de Administração</h1>
        <nav>
            <a href="index.html">Página Inicial</a>
            <a href="admin.php">Administração</a>
        </nav>
    </header>

    <div class="container">
        <section class="search-container">
            <h2>Buscar Projetos</h2>
            <form method="GET" class="search-form">
                <input type="text" name="search" placeholder="Buscar por nome ou descrição..." 
                       value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn btn-primary">Buscar</button>
                <?php if (!empty($search)): ?>
                    <a href="admin.php" class="btn btn-primary">Limpar</a>
                <?php endif; ?>
            </form>
        </section>

        <section class="form-section">
            <h2>Adicionar Novo Projeto</h2>
            <form action="add_project.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Nome do Projeto:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Descrição do Projeto:</label>
                    <textarea id="description" name="description" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="image">Imagem do Projeto (opcional):</label>
                    <input type="file" id="image" name="image" accept="image/*">
                </div>
                
                <button type="submit" class="btn btn-primary">Adicionar Projeto</button>
            </form>
        </section>

        <section>
            <h2>Resultados <?= !empty($search) ? 'da Busca' : 'dos Projetos' ?></h2>
            
            <?php if (count($projects) > 0): ?>
                <table class="projects-table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Descrição</th>
                            <th>Imagem</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($projects as $project): ?>
                            <tr>
                                <td><?= htmlspecialchars($project['name']) ?></td>
                                <td><?= htmlspecialchars($project['description']) ?></td>
                                <td>
                                    <?php if (!empty($project['image'])): ?>
                                        <img src="uploads/<?= htmlspecialchars($project['image']) ?>" 
                                             class="project-image" 
                                             alt="<?= htmlspecialchars($project['name']) ?>">
                                    <?php endif; ?>
                                </td>
                                <td class="actions">
                                    <a href="edit_project.php?id=<?= $project['id'] ?>" class="btn btn-primary">Editar</a>
                                    <a href="admin.php?delete=<?= $project['id'] ?>" 
                                       class="btn btn-danger"
                                       onclick="return confirm('Tem certeza que deseja excluir este projeto?')">
                                        Excluir
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-projects">
                    <p><?= !empty($search) ? 'Nenhum projeto encontrado.' : 'Nenhum projeto cadastrado ainda.' ?></p>
                </div>
            <?php endif; ?>
        </section>
    </div>
</body>
</html>