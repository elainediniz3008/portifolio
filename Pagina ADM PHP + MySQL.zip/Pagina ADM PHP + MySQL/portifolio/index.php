<?php
require 'db_config.php';

$stmt = $pdo->query("SELECT * FROM projects ORDER BY created_at DESC");
$projects = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <!-- [Manter o mesmo HEAD do index.html] -->
</head>
<body>
    <header>
        <h1>Meu Portfólio Profissional</h1>
        <nav>
            <a href="index.php">Início</a>
            <a href="admin.php">Área Admin</a>
        </nav>
    </header>

    <div class="container">
        <h2 class="portfolio-title">Meus Projetos</h2>
        
        <div class="projects-grid">
            <?php foreach ($projects as $project): ?>
                <div class="project-card">
                    <?php if ($project['image']): ?>
                        <img src="uploads/<?= htmlspecialchars($project['image']) ?>" 
                             alt="<?= htmlspecialchars($project['name']) ?>" 
                             class="project-image">
                    <?php else: ?>
                        <div class="project-image" style="background-color: #eee; display: flex; align-items: center; justify-content: center;">
                            <span>Sem imagem</span>
                        </div>
                    <?php endif; ?>
                    <div class="project-info">
                        <h3 class="project-name"><?= htmlspecialchars($project['name']) ?></h3>
                        <p class="project-description"><?= htmlspecialchars($project['description']) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <a href="admin.php" class="admin-link">Área de Administração</a>
    </div>

    <footer>
        <p>&copy; <?= date('Y') ?> Meu Portfólio. Todos os direitos reservados.</p>
    </footer>
</body>
</html>