<?php
require 'db_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $image = null;

    // Processar upload de imagem
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $uploadPath = $uploadDir . $filename;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
            $image = $filename;
        }
    }

    // Inserir no banco de dados
    try {
        $stmt = $pdo->prepare("INSERT INTO projects (name, description, image) VALUES (?, ?, ?)");
        $stmt->execute([$name, $description, $image]);
        
        header("Location: admin.php");
        exit;
    } catch (PDOException $e) {
        die("Erro ao adicionar projeto: " . $e->getMessage());
    }
}

header("Location: admin.php");
?>